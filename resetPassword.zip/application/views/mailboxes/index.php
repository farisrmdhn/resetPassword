<!-- Flash Message -->
<?php if($this->session->flashdata('no_input')): ?>
    <?php echo '<p class="alert alert-danger">'.$this->session->flashdata('no_input').'</p>'; ?>
<?php endif; ?>
<h3><?= $title ?></h3>
<form class="" action="<?php echo base_url(); ?>inbox" method="post">
	<p class="text-red"><?php echo validation_errors(); ?></p>
    <div class="row">
    	<div class="col-md-6">
            <div class="row">
                <div class="form-group col-md-6">
                    <input class="form-control" type="text" name="id" required="">
                </div>
                <div class="form-group col-md-6">
                    <select class="form-control" name="domain" required="">
                        <option value="sneezetify.win" selected="">@sneezetify.win</option>
                        <option value="farisramadhan.com" selected="">@farisramadhan.com</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
		<div class="col-md-6">
            <input class="btn btn-primary float-right" type="submit" name="submit" value="Add">
			<button class="btn btn-warning float-right" id="random" style="color: white; margin-right: 10px;">Random</button>
		</div>
	</div>
</form>